# Data-Analytics-Project-Covid-19-_DA_Batch1

# Intro:
We made this project  as apart of training Data analysis using python  in Aiapproach club.

# Objective
The aim of this notebook is to visualize the total number of cases and deaths caused by Covid-19 in countries on the world map

# About the dataset

Coronavirus disease (COVID-19) is an infectious disease caused by the SARS-CoV-2 virus.

Most people infected with the virus will experience mild to moderate respiratory illness and recover without requiring special treatment. However, some will become seriously ill and require medical attention. Older people and those with underlying medical conditions like cardiovascular disease, diabetes, chronic respiratory disease, or cancer are more likely to develop serious illness. Anyone can get sick with COVID-19 and become seriously ill or die at any age



# Steps :

-Importing required libraries
-Importing data
-Displaying data
-Data Cleaning
-Data visualization
-Discussion
# Conclusion of project:

Top 5 countries which were having more cases world wide were USA ,India ,France, Germany ,and Brazil.

But if we look upon the percentage of morecontamination withh respect to population then Faeroe Islands, San Marino , Austria , Slovenia ,and Brunei.. Because these countries were having bigger percentage ratio of total cases vs population.

Countries which had more death ratio of total deaths vs population were Peru, Bulgaria, Hungary, Bosnia and Herzegovina, North Macedonia

