# storeAnalysis_DA_Bathch1


Startup_investments_data_analysis_project_DA_Batch1

#Intro:
we made this project as apart of training Data analysis using python in Aiapproach club.

# Objective
Coming up with brilliant new startup ideas may be a little bit tricky, and it’s possible to become successful by improving on existing products or old ideas. So by studying the market and the foundation details we can have some insights about where to go and how to think.

# About the dataset
This dataset contains information about startup companies and investment via Crunchbase.
The dataset has various features giving information like the name of the startup, homepage URL, total funding received, the category or the market , country of the startups , region , city , how many funding rounds did the startup get , the first and the last time did the startup receive a fund , the year where the sartup was  founded 
,the seed and the Venture for each startup and the grant that the startup get  .

# Steps :
Here's what we did in this project:
- Exploring the dataset: viewing some rows of it, data description and data information.
- Data cleaning: deleting duplicated rows and null names, renaming some columns, and changing some columns data type.
- Then we used Data analysis principles to show the Companies name  that had maximum total funding in each market.
-  We represented the data using matplotlib to show the percentage of Category based on the total funding.

# Conclusion of project:
We gained some insights about this dataset:
- 86.92% of the startups are operating, the others are either closed or acquired.

- "Software" companies rank first in the list of startups with a total number of 4,620 companies, followed by startups in the field of "biotechnology" with a total number of 3,688 companies, followed by startups in "Mobile" Field with a total number of 1983 companies.

- We got all the details about the company that had the Maximum total funding, and it's 'Verizon Communication' from the 'mobile' market.
Conclusion: if you want to make a startup company it's better for you to think about investing in the software market, specially at the US so your startup would be operating for a long time and it'd get the highest funding.
