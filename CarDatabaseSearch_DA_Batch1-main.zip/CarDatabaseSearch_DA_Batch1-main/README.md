# CarDatabaseSearch_DA_Batch1
It's a try to searching car database in order to answer some simple questions 

# Intro:
we made this project  as apart of training Data analysis using python  in Aiapproach club.

# Objective
1- pass the "Data analysis Training".
2- understand the Status of the cars aviable.
3- understand prices related to cars status.
4- knowing what models are flooding the market with used cars.

# About the dataset
we used kaggle datasets and choose "used and new cars" dataset as shown in link below
https://www.kaggle.com/datasets/georgejnr/used-and-new-cars-datasets

# Steps :
1- Download the Dataset form the link below.
2- after unzipping , create a notebook with jupyter ( I use anaconda - jupyter lab ).
3- importing numpy and pandas library then import the dataset.
4- Analysis the data with pandas then plot the Results.

# Conclusion of project:
1- it containes alot of used and new cars Relative to Other status cars.
2- only new cars are exsited from 2014 and that new cars are huge in the years 2023 and 2022
3- almost new cars are better than Used cars and there is almost 3 thousand only as an average in years from 2000 to 2023
4- the Car models that 75% of them are Used During the interval 2023 to 2000
