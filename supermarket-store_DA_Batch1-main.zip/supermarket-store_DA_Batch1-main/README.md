# supermarket-store_DA_Batch1

# Intro:
we made this project  as apart of training Data analysis using python in Aiapproach club.

# Objective
the aime is analysis supermarket store to help sales manager to know more about prdocuts` sales and customer attributes to improve and increase sales and make higher profit

# About the dataset
dataset column:
Invoice id: Computer generated sales slip invoice identification number
Branch: Branch of supercenter (3 branches are available identified by A, B and C).
City: Location of supercenters
Customer type: Type of customers, recorded by Members for customers using member card and Normal for without member card.
Gender: Gender type of customer
Product line: General item categorization groups - Electronic accessories, Fashion accessories, Food and beverages, Health and beauty, Home and lifestyle, Sports and travel
Unit price: Price of each product in $
Quantity: Number of products purchased by customer
Tax: 5% tax fee for customer buying
Total: Total price including tax
Date: Date of purchase (Record available from January 2019 to March 2019)
Time: Purchase time (10am to 9pm)
Payment: Payment used by customer for purchase (3 methods are available – Cash, Credit card and Ewallet)
COGS: Cost of goods sold
Gross margin percentage: Gross margin percentage
Gross income: Gross income
Rating: Customer stratification rating on their overall shopping experience (On a scale of 1 to 10)

# Steps :
1- import liabrary
2- import data
3- clean data from dublicate and null value
4- describe data
5- Structuring information
6- data visualization 

# Conclusion of project:
supermarket have 3 Branch A,B,C in 3 city Naypyitaw,Yangon,Mandalay 
Customer type 2 type member,normal
Gender male and female
Product line 5 line Fashion accessories,Food and beverages,Electronic accessories,Sports and travel,Home and lifestyle,Health and beauty
Payment 3 ways  Ewallet,Cash,Credit card
Food and Beverages the highest product line in city Naypyitaw and minimum Home and lifestyle
female paid more than Males in naypyitaw 
branch c has the highest average sales
Cash and Ewallet the most common payment ways while Credit Card are less common
The highest Gross income in naypyitaw
max rate Food and beverages,min rate Home and lifestyle
Females are interested in Fashion accessories Males are interested in Health and Beauty 
Member Customers prefer buy Food and beverages , Sports and Travel ,  Normal Customers prefer buy electronic and fashion accessories
Males prefere pay with Ewallet Women prefere pay with Cash
Most sales were in the city of Naypyitaw And on 1/23/2019
The highest sales in month January and city Naypyitaw
In January sold the highest quantity then March then February
The highest cost of good sold in city Naypyitaw and January and 
February the minimum month


