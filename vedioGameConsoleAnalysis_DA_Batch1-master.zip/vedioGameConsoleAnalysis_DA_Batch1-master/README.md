# vedioGameConsoleAnalysis_DA_Batch1
#this project was built by Abdullah Ademi , Abdullah Muqbel , as a part of data analyis trainig course using python in Aiapprouch Club
--------
#objective We analyzed this data to learn about the gaming industry and discover the trends that drive game developers to success!
------
#about the data base This dataset offers a wealth of insights into the dynamics between platform gener. Observe which platforms are driving global sales, what genres have been most successful in different regions across the world, and how both of these factors have changed over time.
-----
#steps: 
1-We showcased our range of gaming consoles and ranked them from highest to lowest for global sales 
2-We arranged game sales by year to see which year is the most influential, in which country, and the reason behind it
3-Then we arranged the types of games and their sales around the world from highest to lowest. 
4-Here we have ranked the best game publishers and developers and their global sales from highest to lowest 
5-We shown the sales of each platform according to the years 
6-We the sales of most types of games during the years.

#conclusion : 
In conclusion, let us recall the best-selling platforms in each period:
1980's: Nintendo:
Ii managed to restore confidence in the whole concept of home gaming. Published the most popular games so far super mario.
----
2009~2010: ps2 
The platform was able to take the lead in that period because it made a practical development, as it was able to integrate three devices in one device.

---
2010~2015: x360, ps4:
The two platforms were able to offer a giant visual development and great processing capacity, and this led to the emergence of more deep and complex games,
which led to the survival of the success of the two generations for a long time.

-What we conclude from this study: The sophistication and development of processing procees and image allow game developers the power to create 
the most interesting games and make the platform the most profitable and longest lasting in the game market.
--
